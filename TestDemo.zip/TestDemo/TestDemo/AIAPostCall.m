//
//  AIAPostCall.m
//  TestDemo
//
//  Created by Jason on 2018/6/28.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import "AIAPostCall.h"

@implementation AIAPostCall
- (NSString *)baseUrl {
    return @"http://v.juhe.cn/historyWeather/province";
    
}

- (NSString *)customRequestUrl {
    return @"http://v.juhe.cn/historyWeather/province";
}

- (DRDRequestMethodType)apiRequestMethodType {
    return DRDRequestMethodTypePOST;
}

- (NSString *)requestMethod {
    return @"post";
}

- (id)requestParameters {
    return @{@"key":@"cb7c716c39fad55bed7d9dc45b30b77d"};
}

- (DRDRequestSerializerType)apiRequestSerializerType {
    return DRDRequestSerializerTypeJSON;
}

- (DRDResponseSerializerType)apiResponseSerializerType {
    return DRDResponseSerializerTypeJSON;
}

@end
