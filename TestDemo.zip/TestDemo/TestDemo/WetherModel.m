//
//  WetherModel.m
//  TestDemo
//
//  Created by Jason on 2018/7/2.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import "WetherModel.h"
#import "YYModel.h"

@implementation WetherModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.ids = value;
    }
}

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"ids" : @[@"id",@"ID"]};
    
}
@end
