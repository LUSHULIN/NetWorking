//
//  AIAPostCall.h
//  TestDemo
//
//  Created by Jason on 2018/6/28.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import <DRDNetworking/DRDNetworking.h>

@interface AIAPostCall : DRDBaseAPI

@end
