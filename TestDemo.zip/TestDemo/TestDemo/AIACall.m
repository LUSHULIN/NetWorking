//
//  AIACall.m
//  TestDemo
//
//  Created by Jason on 2018/6/28.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import "AIACall.h"
#import "WetherModel.h"
#import "YYModel.h"

@implementation AIACall

- (NSMutableArray *)modelList {
    if (_modelList == nil) {
        _modelList = [NSMutableArray array];
    }
    return _modelList;
}

- (NSString *)baseUrl {
     return @"http://v.juhe.cn/historyWeather/province";
    
}

- (NSString *)customRequestUrl {
    return @"http://v.juhe.cn/historyWeather/province";
}

- (DRDRequestMethodType)apiRequestMethodType {
    return DRDRequestMethodTypeGET;
}
- (NSString *)requestMethod {
    return @"get";
}
//key=557152fcd7191627f2805f828dff59be
- (id)requestParameters {
//    return @{@"province":@"",
//                @"dtype":@"json",
//               @"format":@"1",
//             @"callback":@"",
//             @"key":@"557152fcd7191627f2805f828dff59be"
//            };
    return @{@"key":@"cb7c716c39fad55bed7d9dc45b30b77d"};
}

- (DRDRequestSerializerType)apiRequestSerializerType {
    return DRDRequestSerializerTypeJSON;
}

- (DRDResponseSerializerType)apiResponseSerializerType {
    return DRDResponseSerializerTypeJSON;
}

- (id)apiResponseObjReformer:(id)responseObject andError:(NSError *)error {
    if (error != 0) {
        return error;
    }
    NSDictionary *dict = (NSDictionary *)responseObject;
    NSArray *list = dict[@"result"];
    for (NSDictionary *d in list) {
        WetherModel *model = [WetherModel yy_modelWithJSON:d];
        [self.modelList addObject:model];
    }
    return self.modelList;
}

@end
