//
//  AIAActivate.m
//  TestDemo
//
//  Created by Jason on 2018/6/28.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import "AIAActivate.h"

@implementation AIAActivate

- (NSString *)customRequestUrl {
    return @"http://10.132.101.41:8080/iPoS_Indo_Staging/ServerWS";
}

- (DRDRequestMethodType)apiRequestMethodType {
    return DRDRequestMethodTypePOST;
}

- (NSString *)requestMethod {
    return @"post";
}

- (id)requestParameters {
    NSString *str = @"<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><ns2:getServerTimeStamp xmlns:ns2=\"http://ws.ipos.aiaf/\"></ns2:getServerTimeStamp></soap:Body></soap:Envelope>";
    return str;
}

- (DRDRequestSerializerType)apiRequestSerializerType {
    return DRDRequestSerializerTypeXML;
}

- (DRDResponseSerializerType)apiResponseSerializerType {
    return DRDResponseSerializerTypeXML;
}

@end
