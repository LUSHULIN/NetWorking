//
//  WetherModel.h
//  TestDemo
//
//  Created by Jason on 2018/7/2.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WetherModel : NSObject

@property (nonatomic, copy)NSString *ids;
@property (nonatomic, copy)NSString *province;

@end
