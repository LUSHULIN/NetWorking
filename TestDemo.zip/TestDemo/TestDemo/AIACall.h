//
//  AIACall.h
//  TestDemo
//
//  Created by Jason on 2018/6/28.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import <DRDNetworking/DRDNetworking.h>

@interface AIACall : DRDBaseAPI

@property (nonatomic,strong)NSMutableArray *modelList;

@end
