//
//  ViewController.m
//  TestDemo
//
//  Created by Jason on 2018/6/28.
//  Copyright © 2018年 Jason. All rights reserved.
//

#import "ViewController.h"
#import "AIACall.h"
#import "AIAPostCall.h"
#import "AIAActivate.h"
#import "WetherModel.h"
#import "ListTableViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *showStatus;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = [NSArray array];
   
}

- (IBAction)aiaActivation:(id)sender {
    AIAActivate *aia = [[AIAActivate alloc] init];
    NSString *body = aia.requestParameters;
    [aia setApiRequestConstructingBodyBlock:^(id<DRDMultipartFormData>  _Nonnull formData) {
        [formData appendPartWithHeaders:nil body:[body dataUsingEncoding:NSUTF8StringEncoding]];
    }];
    [aia setApiCompletionHandler:^(id  _Nonnull responseObject, NSError * _Nullable error) {
        NSLog(@"responseObject = %@",responseObject);
    }];
    [aia start];
}

- (IBAction)sendPost:(id)sender {
    self.showStatus.text = @"";
    AIAPostCall *call = [[AIAPostCall alloc] init];
    __weak typeof(self) weakSelf = self;
    id _obj = call.requestParameters;
    [call setApiRequestConstructingBodyBlock:^(id<DRDMultipartFormData>  _Nonnull formData) {
       NSDictionary * obj = _obj;
       NSData *data = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:nil];
       [formData appendPartWithHeaders:nil body:data];
    }];
    [call setApiCompletionHandler:^(id  _Nonnull responseObject, NSError * _Nullable error) {
        weakSelf.showStatus.text = responseObject[@"reason"];
    }];
    [call start];
}

- (IBAction)sendGet:(id)sender {
    self.showStatus.text = @"";
    AIACall *call = [[AIACall alloc] init];
    __weak typeof(self) weakSelf = self;
    [call setApiCompletionHandler:^(id  _Nonnull responseObject, NSError * _Nullable error) {
        if (error) {
            weakSelf.showStatus.text = error.description;
        }
        weakSelf.dataList = responseObject;
        WetherModel *model = responseObject[0];
        weakSelf.showStatus.text = model.province;
        [weakSelf performSegueWithIdentifier:@"tableList" sender:sender];
    }];
    [call start];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ListTableViewController *list = segue.destinationViewController;
    list.data = [self.dataList copy];
//    [self.navigationController pushViewController:list animated:true];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
